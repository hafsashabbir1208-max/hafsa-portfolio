const mongoose = require("mongoose");

const projectSchema = new mongoose.Schema({
  title: { type: String, required: true },
  category: { type: String, required: true },
  description: { type: String, required: true },
  stack: { type: [String], default: [] },
  highlight: { type: String, default: "" }
});

module.exports = mongoose.model("Project", projectSchema);
