// server.js
// Express backend for the portfolio site.
// Database: MongoDB via Mongoose (see models/Project.js, models/Message.js).
// If MONGODB_URI isn't set yet, falls back to the local data/projects.json
// file so the project still runs while you're setting up MongoDB Atlas.

require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const mongoose = require("mongoose");
const nodemailer = require("nodemailer");

const Project = require("./models/Project");
const Message = require("./models/Message");

const app = express();
const PORT = process.env.PORT || 5000;
const PROJECTS_FILE = path.join(__dirname, "data", "projects.json");
const MONGODB_URI = process.env.MONGODB_URI;

let dbConnected = false;

async function connectDB() {
  if (!MONGODB_URI) {
    console.warn(
      "MONGODB_URI is not set — running on the local data/projects.json " +
      "fallback instead of a real database. See README.md to connect MongoDB Atlas."
    );
    return;
  }
  try {
    await mongoose.connect(MONGODB_URI);
    dbConnected = true;
    console.log("Connected to MongoDB.");
  } catch (err) {
    console.error("MongoDB connection failed, using local JSON fallback:", err.message);
  }
}

// ---- Email (contact form notifications) ----
const OWNER_EMAIL = "hafsashabbir8343@gmail.com";
const EMAIL_USER = process.env.EMAIL_USER;
const EMAIL_APP_PASSWORD = process.env.EMAIL_APP_PASSWORD;

let transporter = null;
if (EMAIL_USER && EMAIL_APP_PASSWORD) {
  transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: EMAIL_USER, pass: EMAIL_APP_PASSWORD }
  });
} else {
  console.warn(
    "EMAIL_USER / EMAIL_APP_PASSWORD not set — contact messages will be saved " +
    "but not emailed. See README.md to enable email."
  );
}

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "frontend")));

function readLocalProjects() {
  const raw = fs.readFileSync(PROJECTS_FILE, "utf-8");
  return JSON.parse(raw);
}

// ---- Routes ----

// GET /api/projects - list all portfolio projects
app.get("/api/projects", async (req, res) => {
  try {
    if (dbConnected) {
      const projects = await Project.find().lean();
      return res.json(projects);
    }
    res.json(readLocalProjects());
  } catch (err) {
    res.status(500).json({ error: "Could not load projects." });
  }
});

// GET /api/projects/:id - get a single project
app.get("/api/projects/:id", async (req, res) => {
  try {
    if (dbConnected) {
      const project = await Project.findById(req.params.id).lean();
      if (!project) return res.status(404).json({ error: "Project not found." });
      return res.json(project);
    }
    const projects = readLocalProjects();
    const project = projects.find((p) => p.id === Number(req.params.id));
    if (!project) return res.status(404).json({ error: "Project not found." });
    res.json(project);
  } catch (err) {
    res.status(404).json({ error: "Project not found." });
  }
});

// POST /api/contact - store a contact form message (DB) and email the owner
app.post("/api/contact", async (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: "name, email, and message are required." });
  }

  try {
    if (dbConnected) {
      await Message.create({ name, email, message });
    } else {
      const MESSAGES_FILE = path.join(__dirname, "data", "messages.json");
      let messages = [];
      if (fs.existsSync(MESSAGES_FILE)) {
        messages = JSON.parse(fs.readFileSync(MESSAGES_FILE, "utf-8"));
      }
      messages.push({ name, email, message, receivedAt: new Date().toISOString() });
      fs.writeFileSync(MESSAGES_FILE, JSON.stringify(messages, null, 2));
    }
  } catch (err) {
    console.error("Failed to save message:", err.message);
  }

  if (transporter) {
    try {
      await transporter.sendMail({
        from: EMAIL_USER,
        to: OWNER_EMAIL,
        replyTo: email,
        subject: `Portfolio contact form: message from ${name}`,
        text: `From: ${name} <${email}>\n\n${message}`
      });
    } catch (err) {
      console.error("Failed to send email notification:", err.message);
    }
  }

  res.status(201).json({ status: "ok", message: "Message received. Thank you!" });
});

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Portfolio backend running on http://localhost:${PORT}`);
    console.log(`Database: ${dbConnected ? "MongoDB (connected)" : "local JSON fallback"}`);
  });
});
