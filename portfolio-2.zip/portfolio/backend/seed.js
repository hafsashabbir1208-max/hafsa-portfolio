// seed.js
// Loads the starter project data from data/projects.json into MongoDB.
// Run once after connecting your database:
//   node seed.js

require("dotenv").config();
const mongoose = require("mongoose");
const fs = require("fs");
const path = require("path");
const Project = require("./models/Project");

const MONGODB_URI = process.env.MONGODB_URI;

if (!MONGODB_URI) {
  console.error("MONGODB_URI is not set. Add it to your .env file first.");
  process.exit(1);
}

async function seed() {
  await mongoose.connect(MONGODB_URI);
  console.log("Connected to MongoDB.");

  const raw = fs.readFileSync(path.join(__dirname, "data", "projects.json"), "utf-8");
  const projects = JSON.parse(raw).map(({ id, ...rest }) => rest); // drop old local "id"

  await Project.deleteMany({});
  await Project.insertMany(projects);

  console.log(`Seeded ${projects.length} projects into the database.`);
  await mongoose.disconnect();
}

seed().catch((err) => {
  console.error("Seeding failed:", err.message);
  process.exit(1);
});
