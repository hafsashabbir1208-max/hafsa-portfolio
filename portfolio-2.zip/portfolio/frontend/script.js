// Fetch projects from the backend API and render them.
// If the backend isn't running (e.g. static hosting only), falls back
// to the bundled local data so the page still works.

const API_BASE = ""; // same-origin; set to your deployed backend URL if hosted separately

const FALLBACK_PROJECTS = [
  { id: 1, title: "IoT Smart Medicine Box", category: "IoT / Health Tech",
    description: "An IoT-enabled medicine box that reminds patients to take medication on schedule and alerts caregivers if a dose is missed.",
    stack: ["IoT", "Embedded C", "Sensors", "Health Tech"],
    highlight: "Built to solve a real adherence problem for elderly and chronically ill patients." },
  { id: 2, title: "Human Rights Violation Reporting App", category: "Civic Tech",
    description: "A reporting application that lets citizens document and submit human rights violations securely.",
    stack: ["App Development", "Database Design", "Civic Tech"],
    highlight: "Designed with accessibility and anonymity of reporters in mind." },
  { id: 3, title: "Smart Path Generating Electricity", category: "Hackathon / Kinetic Energy",
    description: "A kinetic-energy hackathon project that converts footstep pressure on walkways into usable electrical energy.",
    stack: ["Hardware", "Kinetic Energy", "Sustainability"],
    highlight: "Built under hackathon time constraints, focused on renewable energy from human motion." },
  { id: 4, title: "Spotify Music Data Analysis", category: "Data Science",
    description: "An exploratory data analysis project on Spotify listening data using Python data tooling.",
    stack: ["Python", "Pandas", "Data Visualization"],
    highlight: "Turned raw streaming data into clear, visual listening trend insights." },
  { id: 5, title: "Cardio Disease Prediction", category: "Machine Learning",
    description: "A machine learning model trained to predict cardiovascular disease risk from patient health indicators.",
    stack: ["Python", "Pandas", "Scikit-learn", "ML"],
    highlight: "Applied classification models to a real health-risk prediction problem." }
];

function projectCardHTML(p) {
  const pills = p.stack.map(s => `<span class="stack-pill">${s}</span>`).join("");
  return `
    <article class="project-card">
      <span class="project-category">${p.category}</span>
      <h3>${p.title}</h3>
      <p class="desc">${p.description}</p>
      <p class="project-highlight">${p.highlight}</p>
      <div class="stack-list">${pills}</div>
    </article>
  `;
}

async function loadProjects() {
  const grid = document.getElementById("project-grid");
  try {
    const res = await fetch(`${API_BASE}/api/projects`);
    if (!res.ok) throw new Error("Bad response");
    const projects = await res.json();
    grid.innerHTML = projects.map(projectCardHTML).join("");
  } catch (err) {
    // Backend not reachable — use bundled data so the page still renders.
    grid.innerHTML = FALLBACK_PROJECTS.map(projectCardHTML).join("");
  }
}

function initContactForm() {
  const form = document.getElementById("contact-form");
  const status = document.getElementById("form-status");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      name: form.name.value.trim(),
      email: form.email.value.trim(),
      message: form.message.value.trim()
    };
    status.textContent = "Sending…";
    status.classList.remove("error");

    try {
      const res = await fetch(`${API_BASE}/api/contact`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Failed to send");
      status.textContent = "Message sent — thank you! I'll get back to you soon.";
      form.reset();
    } catch (err) {
      status.textContent = "Couldn't reach the server. Please email me directly instead.";
      status.classList.add("error");
    }
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadProjects();
  initContactForm();
});
