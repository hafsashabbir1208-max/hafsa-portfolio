# Hafsa's Personal Portfolio Website

A full-stack portfolio site:
- **Frontend:** HTML, CSS, JavaScript
- **Backend:** Node.js / Express
- **Database:** MongoDB (via Mongoose) — falls back to a local JSON file automatically if MongoDB isn't connected yet, so the project always runs
- **Deployment-ready** for Netlify (frontend) + Render (backend)

## Structure
```
portfolio/
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── backend/
│   ├── server.js
│   ├── seed.js              # loads starter project data into MongoDB
│   ├── package.json
│   ├── .env.example
│   ├── models/
│   │   ├── Project.js
│   │   └── Message.js
│   └── data/
│       └── projects.json    # fallback data, also used to seed MongoDB
└── README.md
```

## 1. Run it locally (quick check, no database needed)
```bash
cd backend
npm install
npm start
```
Open **http://localhost:5000**. Without a database connected, it automatically
uses the local `data/projects.json` file, so everything works out of the box.

## 2. Set up the real database (MongoDB Atlas — free tier)
1. Create a free account at https://www.mongodb.com/cloud/atlas/register
2. Create a free **M0 cluster**.
3. Under **Database Access**, add a database user with a username/password.
4. Under **Network Access**, add `0.0.0.0/0` (allow access from anywhere) —
   simplest option for a student project/demo.
5. Click **Connect → Drivers**, copy the connection string. It looks like:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
6. In `backend/`, copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
7. Paste your connection string into `.env` as `MONGODB_URI`, adding a database
   name before the `?`, e.g. `.../portfolio?retryWrites=true...`
8. Load the starter project data into MongoDB:
   ```bash
   npm run seed
   ```
9. Start the server:
   ```bash
   npm start
   ```
   The terminal will print `Database: MongoDB (connected)` once it's working.

## 3. Turn on contact-form email notifications (optional)
1. Turn on 2-Step Verification on hafsashabbir8343@gmail.com:
   https://myaccount.google.com/security
2. Generate an App Password: https://myaccount.google.com/apppasswords
3. Add to `.env`:
   ```
   EMAIL_USER=hafsashabbir8343@gmail.com
   EMAIL_APP_PASSWORD=the16charpassword
   ```
Without this, messages are still saved to the database — you just won't get
an email alert.

## 4. Deploy it (needed before submitting to Thiranex)

**Step A — Push to GitHub**
```bash
git init
git add .
git commit -m "Portfolio website"
```
Create a new repo on GitHub and push this project to it.

**Step B — Deploy the backend on Render**
1. Go to https://render.com → New → Web Service → connect your GitHub repo.
2. Root directory: `backend`
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables (from your `.env`): `MONGODB_URI`, `EMAIL_USER`,
   `EMAIL_APP_PASSWORD`.
6. Deploy. You'll get a live URL like `https://your-app.onrender.com`.

**Step C — Deploy the frontend on Netlify**
1. Go to https://app.netlify.com → Add new site → Import from GitHub.
2. Publish directory: `frontend`
3. Before deploying, open `frontend/script.js` and set:
   ```js
   const API_BASE = "https://your-app.onrender.com";
   ```
   Commit and push this change so Netlify picks it up.
4. Deploy. You'll get a live URL like `https://your-site.netlify.app`.

**This Netlify link is what you submit to the Thiranex dashboard.**

*Note: Render's free tier sleeps after inactivity, so the first load after a
while may take ~30 seconds to wake up — this is normal for free hosting.*
